<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-Frame-Options" content="ALLOWALL">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Countdown Practice — CSHS</title>
<style>
  @import url('../../assets/fonts/fonts.css');
  :root {
    --green:#00180f; --green-mid:#003d1f; --green-light:#005a2e;
    --gold:#f2b400; --gold-dim:rgba(242,180,0,0.15); --gold-border:rgba(242,180,0,0.3);
    --white:#fdfdfd; --muted:rgba(255,255,255,0.55); --danger:#e05252; --correct:#4caf7a;
  }
  *{box-sizing:border-box;margin:0;padding:0;}
  body{font-family:'DM Sans',sans-serif;background:var(--green);color:var(--white);min-height:100vh;overflow-x:hidden;}
  body::before{content:'';position:fixed;inset:0;background:radial-gradient(ellipse 80% 50% at 20% 0%,rgba(0,90,46,0.4) 0%,transparent 60%),radial-gradient(ellipse 60% 40% at 80% 100%,rgba(242,180,0,0.08) 0%,transparent 60%);pointer-events:none;z-index:0;}
  .container{max-width:680px;margin:0 auto;padding:24px 16px;position:relative;z-index:1;}
  .header{text-align:center;margin-bottom:24px;}
  .header-eyebrow{font-family:'DM Mono',monospace;font-size:10px;letter-spacing:0.2em;color:var(--gold);text-transform:uppercase;margin-bottom:8px;}
  .header h1{font-family:'Bebas Neue',sans-serif;font-size:clamp(52px,12vw,96px);color:var(--white);letter-spacing:0.05em;line-height:0.9;}
  .header h1 span{color:var(--gold);}
  .header-sub{font-size:13px;color:var(--muted);margin-top:8px;}
  .tabs{display:flex;gap:4px;margin-bottom:20px;background:rgba(255,255,255,0.04);border-radius:10px;padding:4px;}
  .tab{flex:1;padding:8px 12px;border-radius:7px;font-size:13px;font-weight:600;cursor:pointer;text-align:center;transition:all 0.15s;color:var(--muted);border:none;background:transparent;}
  .tab.active{background:var(--gold);color:var(--green);}
  .section{display:none;} .section.active{display:block;}
  .card{background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:16px;padding:24px;margin-bottom:20px;}
  .card-title{font-family:'DM Mono',monospace;font-size:10px;letter-spacing:0.18em;text-transform:uppercase;color:var(--gold);margin-bottom:16px;}
  .group-select{display:grid;grid-template-columns:repeat(auto-fill,minmax(100px,1fr));gap:8px;margin-bottom:8px;}
  .group-btn{background:var(--gold-dim);border:1px solid var(--gold-border);color:var(--white);padding:10px 8px;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:13px;font-weight:600;cursor:pointer;transition:all 0.15s;text-align:center;}
  .group-btn:hover{background:rgba(242,180,0,0.28);border-color:var(--gold);}
  .group-btn.selected{background:var(--gold);color:var(--green);border-color:var(--gold);}
  .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:12px 24px;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:14px;font-weight:700;cursor:pointer;border:none;transition:all 0.15s;letter-spacing:0.02em;}
  .btn-primary{background:var(--gold);color:var(--green);}
  .btn-primary:hover{background:#ffc820;transform:translateY(-1px);box-shadow:0 4px 16px rgba(242,180,0,0.3);}
  .btn-primary:disabled{opacity:0.4;cursor:not-allowed;transform:none;box-shadow:none;}
  .btn-outline{background:transparent;color:var(--gold);border:1px solid var(--gold-border);}
  .btn-outline:hover{background:var(--gold-dim);}
  .btn-danger{background:transparent;color:var(--danger);border:1px solid rgba(224,82,82,0.3);font-size:12px;padding:8px 14px;}
  .btn-danger:hover{background:rgba(224,82,82,0.1);}
  .full-width{width:100%;}
  /* Target display */
  .target-display{text-align:center;margin:20px 0;}
  .target-label{font-family:'DM Mono',monospace;font-size:10px;letter-spacing:0.2em;color:var(--muted);text-transform:uppercase;margin-bottom:8px;}
  .target-number{font-family:'Bebas Neue',sans-serif;font-size:96px;color:var(--gold);line-height:1;text-shadow:0 0 40px rgba(242,180,0,0.3);}
  /* Number tiles */
  .number-tiles{display:flex;flex-wrap:wrap;gap:10px;justify-content:center;margin:20px 0;}
  .num-tile{width:72px;height:72px;background:rgba(255,255,255,0.08);border:2px solid rgba(255,255,255,0.15);border-radius:12px;display:flex;align-items:center;justify-content:center;font-family:'Bebas Neue',sans-serif;font-size:36px;color:var(--white);cursor:pointer;transition:all 0.15s;user-select:none;}
  .num-tile:hover{background:rgba(242,180,0,0.15);border-color:var(--gold);}
  .num-tile.used{opacity:0.25;cursor:not-allowed;pointer-events:none;}
  .num-tile.large-num{background:rgba(242,180,0,0.12);border-color:rgba(242,180,0,0.4);color:var(--gold);}
  /* Calculator */
  .calc-display{background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.15);border-radius:10px;padding:12px 16px;font-family:'DM Mono',monospace;font-size:18px;color:var(--white);min-height:52px;margin-bottom:12px;word-break:break-all;}
  .calc-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px;}
  .op-btn{padding:14px;border-radius:8px;font-family:'DM Mono',monospace;font-size:18px;font-weight:700;cursor:pointer;border:none;background:rgba(255,255,255,0.08);color:var(--white);transition:all 0.15s;}
  .op-btn:hover{background:rgba(255,255,255,0.15);}
  .op-btn.equals{background:var(--gold);color:var(--green);grid-column:span 2;}
  .op-btn.clear{background:rgba(224,82,82,0.2);color:var(--danger);}
  .op-btn.backspace{background:rgba(255,255,255,0.05);color:var(--muted);}
  /* Timer */
  .timer-bar-wrap{height:6px;background:rgba(255,255,255,0.1);border-radius:3px;margin-bottom:16px;overflow:hidden;}
  .timer-bar{height:100%;background:var(--gold);border-radius:3px;transition:width 1s linear,background 0.3s;}
  .timer-bar.urgent{background:var(--danger);}
  .timer-text{font-family:'Bebas Neue',sans-serif;font-size:28px;color:var(--gold);text-align:center;margin-bottom:8px;}
  .timer-text.urgent{color:var(--danger);}
  /* Result */
  .score-big{font-family:'Bebas Neue',sans-serif;font-size:80px;color:var(--gold);line-height:1;text-align:center;}
  .score-label{font-size:13px;color:var(--muted);text-align:center;margin-top:4px;}
  .result-detail{font-size:14px;color:rgba(255,255,255,0.8);text-align:center;margin-top:8px;line-height:1.6;}
  /* Week chip */
  .week-info{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
  .week-chip{background:var(--gold-dim);border:1px solid var(--gold-border);border-radius:20px;padding:4px 12px;font-size:12px;color:var(--gold);font-weight:600;}
  /* Admin */
  .admin-panel{display:none;} .admin-panel.open{display:block;}
  .admin-field{margin-bottom:14px;}
  .admin-field label{display:block;font-size:11px;color:var(--muted);margin-bottom:6px;text-transform:uppercase;letter-spacing:0.1em;}
  .admin-input{width:100%;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.15);border-radius:8px;padding:10px 12px;color:var(--white);font-family:'DM Sans',sans-serif;font-size:14px;}
  .admin-input:focus{outline:none;border-color:var(--gold);}
  .admin-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;}
  .flex-between{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;}
  .mt16{margin-top:16px;}
  .toast{position:fixed;top:24px;left:50%;transform:translateX(-50%) translateY(-80px);background:var(--white);color:var(--green);padding:10px 20px;border-radius:8px;font-weight:700;font-size:14px;z-index:100;transition:transform 0.3s ease;pointer-events:none;}
  .toast.show{transform:translateX(-50%) translateY(0);}
  @media(max-width:480px){.num-tile{width:60px;height:60px;font-size:28px;} .admin-grid{grid-template-columns:1fr;}}
</style>
</head>
<body>
<div class="toast" id="toast"></div>
<div class="container">
  <div class="header">
    <div class="header-eyebrow">Corinda State High School · Practice Mode</div>
    <h1>COUNT<span>DOWN</span></h1>
    <div class="header-sub">Unlimited practice — a fresh target every round, not the leaderboard target</div>
  </div>

  <div class="tabs">
    <button class="tab active" onclick="switchTab('game')">Game</button>
  </div>

  <!-- GAME TAB -->
  <div id="tab-game" class="section active">

    <!-- Play -->
    <div id="screen-signin" class="section active">
      <div class="card">
        <div class="card-title">Practice Mode</div>
        <p style="font-size:14px;color:var(--muted);line-height:1.6;margin-bottom:16px;">Play as many rounds as you like. Every round uses a fresh target and numbers — never this week's official Home Group target — and nothing is submitted to the leaderboard.</p>
        <button class="btn btn-primary full-width" id="startBtn" onclick="startGame()">Start Practice Round</button>
      </div>
      <div class="card">
        <div class="card-title">Practice details</div>
        <div class="week-info" id="weekInfo"></div>
      </div>
    </div>

    <!-- Playing -->
    <div id="screen-playing" class="section">
      <div class="card">
        <div class="flex-between" style="margin-bottom:12px;">
          <div class="card-title" style="margin-bottom:2px;">Practice Round</div>
          <div style="text-align:right;">
            <div class="timer-text" id="timerText">3:00</div>
          </div>
        </div>
        <div class="timer-bar-wrap"><div class="timer-bar" id="timerBar"></div></div>
        <div class="target-display">
          <div class="target-label">Target</div>
          <div class="target-number" id="targetDisplay">—</div>
        </div>
        <div class="number-tiles" id="numberTiles"></div>
        <div class="calc-display" id="calcDisplay">Select a number to begin...</div>
        <div class="calc-grid">
          <button class="op-btn" onclick="addOp('+')">+</button>
          <button class="op-btn" onclick="addOp('-')">−</button>
          <button class="op-btn" onclick="addOp('×')">×</button>
          <button class="op-btn" onclick="addOp('÷')">÷</button>
          <button class="op-btn clear" onclick="clearCalc()">Clear</button>
          <button class="op-btn backspace" onclick="backspace()">⌫</button>
          <button class="op-btn equals" onclick="evaluateExpression()">=</button>
        </div>
        <button class="btn btn-primary full-width" id="submitAnswerBtn" onclick="submitAnswer()" disabled>Submit Answer</button>
      </div>
    </div>

    <!-- Result -->
    <div id="screen-result" class="section">
      <div class="card">
        <div class="card-title">Round complete</div>
        <div style="padding:16px 0;">
          <div style="font-size:36px;text-align:center;margin-bottom:8px;" id="resultEmoji">🎯</div>
          <div class="score-big" id="finalScore">0</div>
          <div class="score-label">out of 10</div>
          <div class="result-detail" id="resultDetail"></div>
        </div>
        <div style="display:flex;flex-direction:column;gap:10px;margin-top:16px;">
          <button class="btn btn-primary full-width" onclick="startGame()" style="font-size:16px;padding:14px;">🔁 Play Again</button>
          <button class="btn btn-outline full-width" onclick="resetToSignin()">← Back to practice menu</button>
        </div>
      </div>
    </div>

  </div>

  <!-- ADMIN TAB -->
  

</div>

<script src="../../assets/site-config.js"></script>
<script>
/* ── AUTO WEEK (shared across all CSHS games) ──────────────────────────────
   Returns the current configured CSHS school week as {term, week, absWeek 1..40}.
   absWeek lets games index a content bank continuously across the year.
   Rule: latest term-week whose Monday is on/before today; holidays hold the
   most recent week; before the year starts, week 1. Matches Wheel of Fortune. */
const CSHS_TERMS = window.CSHS_SITE_CONFIG.terms;
function cshsWeekSchedule(){
  const parse=s=>{const[y,m,d]=s.split('-').map(Number);return new Date(y,m-1,d);};
  const mondayOf=d=>{const x=new Date(d);const dow=(x.getDay()+6)%7;x.setDate(x.getDate()-dow);x.setHours(0,0,0,0);return x;};
  const out=[]; let abs=0;
  for(const term of CSHS_TERMS){
    const end=parse(term.end); let mon=mondayOf(parse(term.start)); let w=1;
    while(mon<=end){ abs++; out.push({t:term.t,w,abs,mon:new Date(mon)}); mon=new Date(mon); mon.setDate(mon.getDate()+7); w++; }
  }
  return out;
}
function cshsCurrentWeek(){
  const sched=cshsWeekSchedule();
  const today=new Date(); today.setHours(0,0,0,0);
  let chosen=sched[0];
  for(const wk of sched){ if(wk.mon<=today) chosen=wk; else break; }
  return chosen; // {t,w,abs,mon}
}

function cshsWeekLabel(){ const w=cshsCurrentWeek(); return `Term ${w.t} · Week ${w.w}`; }

// 40-week verified Countdown bank (every target solvable from its six numbers)
const COUNTDOWN_BANK = [
  { numbers:[9,50,3,25,9,8], target:784 },
  { numbers:[25,8,10,5,2,1], target:960 },
  { numbers:[9,7,25,100,5,10], target:844 },
  { numbers:[3,2,50,25,1,100], target:235 },
  { numbers:[2,10,7,5,25,3], target:694 },
  { numbers:[100,10,3,25,2,10], target:855 },
  { numbers:[1,10,25,6,9,100], target:751 },
  { numbers:[3,7,6,3,100,7], target:819 },
  { numbers:[3,9,3,25,75,1], target:930 },
  { numbers:[25,3,50,3,8,75], target:805 },
  { numbers:[75,2,8,1,6,100], target:923 },
  { numbers:[3,50,8,5,7,4], target:355 },
  { numbers:[7,25,10,100,5,9], target:392 },
  { numbers:[100,7,50,75,2,10], target:195 },
  { numbers:[5,2,1,6,50,3], target:465 },
  { numbers:[25,4,8,75,1,9], target:177 },
  { numbers:[3,10,5,25,2,100], target:879 },
  { numbers:[10,1,4,2,9,25], target:247 },
  { numbers:[100,7,3,25,4,4], target:323 },
  { numbers:[9,50,75,2,25,8], target:417 },
  { numbers:[50,4,10,25,2,3], target:971 },
  { numbers:[3,4,5,100,10,7], target:325 },
  { numbers:[8,100,3,75,10,2], target:719 },
  { numbers:[50,6,25,100,6,4], target:969 },
  { numbers:[4,10,25,4,9,8], target:867 },
  { numbers:[7,1,10,100,9,75], target:448 },
  { numbers:[50,9,100,4,7,6], target:429 },
  { numbers:[6,6,75,8,2,2], target:613 },
  { numbers:[3,50,4,100,10,7], target:856 },
  { numbers:[75,7,9,25,9,100], target:757 },
  { numbers:[3,100,25,10,8,3], target:372 },
  { numbers:[100,9,7,2,10,4], target:763 },
  { numbers:[1,75,6,2,10,50], target:676 },
  { numbers:[75,9,50,9,100,10], target:629 },
  { numbers:[25,9,5,1,4,3], target:636 },
  { numbers:[8,5,100,1,10,25], target:736 },
  { numbers:[75,3,25,8,5,10], target:183 },
  { numbers:[4,4,100,3,8,6], target:202 },
  { numbers:[6,9,10,75,50,5], target:365 },
  { numbers:[100,50,8,7,25,1], target:362 }
];

// Load this week's puzzle into config (date-driven)
// Picks a random round from the weekly bank, excluding the current live
// Home Group week's official target/numbers so practice never gives away the answer.
function getPracticeRound(){
  const abs = cshsCurrentWeek().abs;
  const officialRound = COUNTDOWN_BANK[(abs - 1) % COUNTDOWN_BANK.length];
  const pool = COUNTDOWN_BANK.filter(p => p !== officialRound);
  return pool[Math.floor(Math.random() * pool.length)];
}

const DEFAULT_CONFIG = { timeSecs: 180 };

let config = { ...DEFAULT_CONFIG };
let timerInterval = null, timeLeft = 180;
let calcExpression = '', usedIndices = new Set();
let currentResult = null, gameActive = false;

// ─── INIT ─────────────────────────────────────────────────────────────────────
function init() {
  renderWeekPreview();
}

function renderWeekPreview() {
  document.getElementById('weekInfo').innerHTML = `
    <div class="week-chip">Unlimited practice</div>
    <div class="week-chip">New target each round</div>
    <div class="week-chip">3 min round</div>
  `;
}

// ─── GAME ─────────────────────────────────────────────────────────────────────
function startGame() {
  const round = getPracticeRound();
  config.numbers = round.numbers.slice();
  config.target  = round.target;
  document.getElementById('targetDisplay').textContent = config.target;
  calcExpression = ''; currentResult = null; usedIndices = new Set(); gameActive = true;
  buildNumberTiles();
  updateCalcDisplay();
  document.getElementById('submitAnswerBtn').disabled = true;
  startTimer();
  showScreen('screen-playing');
}

function buildNumberTiles() {
  const el = document.getElementById('numberTiles');
  const largeNums = [25, 50, 75, 100];
  el.innerHTML = config.numbers.map((n, i) => {
    const isLarge = largeNums.includes(n);
    return `<div class="num-tile ${isLarge?'large-num':''}" id="tile-${i}" onclick="addNumber(${n}, ${i})">${n}</div>`;
  }).join('');
}

function addNumber(n, idx) {
  if (!gameActive || usedIndices.has(idx)) return;
  usedIndices.add(idx);
  document.getElementById(`tile-${idx}`).classList.add('used');
  calcExpression += (calcExpression === '' ? '' : '') + n;
  updateCalcDisplay();
}

function addOp(op) {
  if (!gameActive) return;
  const last = calcExpression.slice(-1);
  if (calcExpression === '' || ['+','-','×','÷','('].includes(last)) return;
  calcExpression += ' ' + op + ' ';
  updateCalcDisplay();
}

function clearCalc() {
  calcExpression = ''; usedIndices = new Set(); currentResult = null;
  document.getElementById('submitAnswerBtn').disabled = true;
  buildNumberTiles();
  updateCalcDisplay();
}

function backspace() {
  if (!gameActive) return;
  // Simple backspace — remove last char/number
  calcExpression = calcExpression.trimEnd();
  const parts = calcExpression.split(' ');
  parts.pop();
  calcExpression = parts.join(' ');
  updateCalcDisplay();
  // Re-enable tiles (simple approach — rebuild)
  usedIndices = new Set();
  buildNumberTiles();
  // Mark used numbers based on current expression
  const nums = calcExpression.match(/\d+/g) || [];
  const available = [...config.numbers];
  nums.forEach(n => {
    const idx = available.indexOf(parseInt(n));
    if (idx !== -1) { usedIndices.add(idx); available[idx] = null; document.getElementById(`tile-${idx}`)?.classList.add('used'); }
  });
}

function updateCalcDisplay() {
  const el = document.getElementById('calcDisplay');
  el.textContent = calcExpression || 'Select a number to begin...';
}

function evaluateExpression() {
  if (!gameActive || !calcExpression.trim()) { showToast('Enter a calculation first'); return; }
  const last = calcExpression.trim().slice(-1);
  if (['+','-','×','÷'].includes(last)) { showToast('Finish your calculation — remove the last operator'); return; }
  try {
    const safe = calcExpression.replace(/×/g,'*').replace(/÷/g,'/');
    const result = Function('"use strict"; return (' + safe + ')')();
    if (!Number.isFinite(result)) { showToast('Result must be a number'); return; }
    if (result <= 0) { showToast('Result must be a positive number'); return; }
    if (!Number.isInteger(result)) { showToast('Result must be a whole number — check your division'); return; }
    currentResult = result;
    calcExpression = calcExpression + ' = ' + result;
    updateCalcDisplay();
    document.getElementById('submitAnswerBtn').disabled = false;
  } catch(e) {
    showToast('Invalid calculation — check for missing numbers between operators');
  }
}

function submitAnswer() {
  if (!gameActive || currentResult === null) return;
  gameActive = false;
  clearInterval(timerInterval);
  const diff = Math.abs(currentResult - config.target);
  // Smooth curve by accuracy: exact->10, <=5->9, <=10->8, <=25->7, <=50->6.
  // Submitted an answer further off -> 3 for having a go. (No answer handled in timeExpired -> 0.)
  let scaled, label;
  if (diff === 0)      { scaled = 10; label = '🎯 Exact!'; }
  else if (diff <= 5)  { scaled = 9;  label = `${diff} away`; }
  else if (diff <= 10) { scaled = 8;  label = `${diff} away`; }
  else if (diff <= 25) { scaled = 7;  label = `${diff} away`; }
  else if (diff <= 50) { scaled = 6;  label = `${diff} away`; }
  else                 { scaled = 3;  label = `${diff} away — 3 for having a go`; }

  document.getElementById('resultEmoji').textContent = diff === 0 ? '🎯' : diff <= 25 ? '👍' : '🙂';
  document.getElementById('finalScore').textContent = scaled;
  document.getElementById('resultDetail').innerHTML = `Your answer: <strong>${currentResult}</strong><br>Target: <strong>${config.target}</strong><br>${label} → ${scaled} out of 10`;
  showScreen('screen-result');
}

// ─── TIMER ────────────────────────────────────────────────────────────────────
function startTimer() {
  timeLeft = config.timeSecs;
  const bar = document.getElementById('timerBar');
  const text = document.getElementById('timerText');
  bar.style.width = '100%'; bar.classList.remove('urgent');
  text.classList.remove('urgent');
  timerInterval = setInterval(() => {
    timeLeft--;
    const pct = (timeLeft / config.timeSecs) * 100;
    bar.style.width = pct + '%';
    const mins = Math.floor(timeLeft / 60);
    const secs = timeLeft % 60;
    text.textContent = mins + ':' + String(secs).padStart(2, '0');
    if (timeLeft <= 30) { bar.classList.add('urgent'); text.classList.add('urgent'); }
    if (timeLeft <= 0) { clearInterval(timerInterval); timeExpired(); }
  }, 1000);
}

function timeExpired() {
  gameActive = false;
  if (currentResult !== null) {
    submitAnswer();
  } else {
    document.getElementById('resultEmoji').textContent = '⏰';
    document.getElementById('finalScore').textContent = 0;
    document.getElementById('resultDetail').textContent = 'Time\'s up — no answer submitted → 0 out of 10';
    showScreen('screen-result');
  }
}

// ─── SCREENS ──────────────────────────────────────────────────────────────────
function showScreen(id) {
  ['screen-signin','screen-playing','screen-result'].forEach(s =>
    document.getElementById(s).classList.toggle('active', s === id)
  );
}

function resetToSignin() {
  clearInterval(timerInterval); gameActive = false;
  showScreen('screen-signin');
}

// ─── TABS ─────────────────────────────────────────────────────────────────────
function switchTab(name) {
  ['game','admin'].forEach(t => document.getElementById(`tab-${t}`).classList.toggle('active', t === name));
  document.querySelectorAll('.tab').forEach((btn, i) => btn.classList.toggle('active', ['game','admin'][i] === name));
}

// ─── TOAST ────────────────────────────────────────────────────────────────────
let toastTimer = null;
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2500);
}

init();

</script>
</body>
</html>
